██╗░░░██╗███████╗██╗░░██╗  ░██████╗███████╗██████╗░██╗░░░██╗██╗░█████╗░███████╗░██████╗
██║░░░██║██╔════╝╚██╗██╔╝  ██╔════╝██╔════╝██╔══██╗██║░░░██║██║██╔══██╗██╔════╝██╔════╝
╚██╗░██╔╝█████╗░░░╚███╔╝░  ╚█████╗░█████╗░░██████╔╝╚██╗░██╔╝██║██║░░╚═╝█████╗░░╚█████╗░
░╚████╔╝░██╔══╝░░░██╔██╗░  ░╚═══██╗██╔══╝░░██╔══██╗░╚████╔╝░██║██║░░██╗██╔══╝░░░╚═══██╗
░░╚██╔╝░░███████╗██╔╝╚██╗  ██████╔╝███████╗██║░░██║░░╚██╔╝░░██║╚█████╔╝███████╗██████╔╝
░░░╚═╝░░░╚══════╝╚═╝░░╚═╝  ╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚══════╝╚═════╝░
Thank you for using our Custom Nuke Bot!   
*----------------------------------------*
		*About*
Tested with Python 3.10.0
Version 1.0.0
Made By: StanTheMan#6969
Discord: https://discord.gg/y9JCRYWvE4
*----------------------------------------*

*----------------------------------------**----------------------------------------**-------------------------------------------------------------------*
**How To Start Nuke Bot** + More **

- First download the exe called "VexNukeBot.exe" 
- After downloading go to windows settings and turn off windows virus protection settings (this will make it so when you open the file windows won't
instantly delete or block it)
- After doing that go here: https://discord.com/developers/applications (this is where you'll make your bot and insert it in the server you want to 
nuke or use the commands) 
- After your done open the "VexNukeBot.exe" and follow the steps it tells you to do.
- If you need any help or if there are any problems please go to #HELP or @Support in our Discord Server!
*----------------------------------------**----------------------------------------**-------------------------------------------------------------------*
**Enjoy using our bot have fun and don't be a skid.**  Do .help to show Commands 

